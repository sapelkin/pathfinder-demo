"""Pathfinder's simulation engine: a file-by-file Python port of ``Pathfinder/Pathfinder/Engine/*.swift`` and of
the behaviour in ``App/AppModel.swift`` and ``App/GuidedDemo.swift`` (``model.py``, ``demo.py``)."""

__version__ = "0.1.0"
